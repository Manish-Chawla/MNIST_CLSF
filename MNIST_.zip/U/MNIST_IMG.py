import Image
import struct
import os
import math
import sys;


	

class img_matrix:
	
	def __init__(self,dim,raw_data):
		self.matrix = [];
		self.dim = dim;
		i = 0;
		image_row = [];

		for byte in raw_data:

			if(i == dim):
				self.matrix.append(image_row);
				i = 0;
				image_row = [];
		
			pixel_value = struct.unpack(">B",byte);
			image_row.append(pixel_value[0]);
			i=i+1;

		self.matrix.append(image_row);
	
		
	def GetLowest(self,matrix):
		L = len(matrix);
		for x in xrange(0,L):
			for y in xrange(0,L):
				if( matrix[x][y] == 1):
					return (x,y);
	def ShowImage(self,matrix = []):
		elements = [];
		if(matrix!= []):
			show_matrix = matrix;
		else:
			show_matrix = self.matrix;


		for row in show_matrix:
			for elem in row:
				elements.append((elem));
		
		
		im = Image.new('L',(len(show_matrix),len(show_matrix)));
		im.putdata(elements);
		im.show();
		
		
	
	def PrintMatrix(self,matrix):
		dim = len(matrix);
		for i in range(dim):
			for j in range(dim):
				print matrix[i][j],
			print "";

	def sum_rad(self,matrix,(x,y),R,funct):
		sum_ = 0;
		L = len(matrix);
		for i in xrange((-1)*R,R+1):
			for j in xrange((-1)*R,R+1):
				if( ((x+i,y+j) >= (0,0)) and ((x+i,y+j) < (L,L)) ):
					sum_ = sum_ + funct( (x+i,y+j),(x,y) );
		return float(sum_)/((2*R+1)**2);

	def cosine(self,(x1,y1),(x2,y2)):
		D = math.sqrt( (x1-x2)**2 + (y1-y2)**2 );
		if( D == 0):
			return 0;
		return (x2 - x1)/D;

	def nearest_neighbour(self,matrix,(x,y)):
		D = len(matrix);
		for i in xrange(-1,2):
			for j in xrange(-1,2):
				if( ((i,j) != (0,0)) and ( (x+i) >= 0 ) and ( (y+j) >= 0) and ( (x+i) < D) and ( (y+j) < D) and (matrix[x+i][y+j] == 1)):
					return (x+i,y+j);
		return (-1,-1);
	

	#Feature Extraction methods

	def GetCenter(self):
		cm = 0;
		for i in xrange(0, len(self.matrix)):
			for j in xrange( 0,len(self.matrix[0]) ):
				if(self.matrix[i][j] > 0):
					cm = cm+1;
		return float(cm)/((self.dim)**2);


	def GetBoundary(self):
		bounding_letter = [];
		for x in xrange(0,self.dim):
			bounding_letter.append([x*0 for x in xrange(0,self.dim)]);
		
		for i in xrange(1,self.dim-1):
			for j in xrange(1,self.dim-1):
				if( self.matrix[i][j] > 0 ):
					if ( (self.matrix[i][j-1] == 0) or (self.matrix[i][j+1] == 0) ):
						bounding_letter[i][j] = 1;
				
					if( (self.matrix[i-1][j] == 0) or (self.matrix[i+1][j] == 0) ):
						bounding_letter[i][j] = 1;
					
					if( (self.matrix[i-1][j-1] == 0) or (self.matrix[i-1][j+1] == 0)):
						bounding_letter[i][j] = 1;
					
					if( (self.matrix[i+1][j-1] == 0) or (self.matrix[i+1][j+1] == 0)):
						bounding_letter[i][j] = 1;
		
			

		return bounding_letter; 


	def LabelComponent(self,matrix,(x,y),label):
		side = len(matrix);

		if( ( matrix[x][y] == 0)  ):	#(x,y) unvisited
		
			matrix[x][y] = label;

			if( x+1 < side):
				self.LabelComponent(matrix,(x+1,y),label);

			if( x-1 >= 0 ):
				self.LabelComponent(matrix,(x-1,y),label);

			if( y-1 >= 0 ):
				self.LabelComponent(matrix,(x,y-1),label);

			if( y+1 < side ):
				self.LabelComponent(matrix,(x,y+1),label);
				

	def LabelRegions(self):
		label_matrix = [ [0 for i in xrange(self.dim)] for j in xrange(self.dim) ];
		
		
		for i in xrange(self.dim):
			for j in xrange(self.dim):
				if(self.matrix[i][j] > 100):
					label_matrix[i][j] = 1;
		
		label_num = 2;
		for i in xrange(self.dim):
			for j in xrange(self.dim):
				if( label_matrix[i][j] == 0 ):	
					self.LabelComponent(label_matrix,(i,j),label_num);
					label_num = label_num+1;
		
		return label_num;
		
	
	def GetDistance(self,dist_matrix,src_matrix,(i,j)):		#get distance of (i,j) from boundary
		if( src_matrix[i][j] == 0):
			dist_matrix[i][j] = 0;


		if( src_matrix[i][j] == 1):

			dxr = dxl = 0;		#x-axis right,left distance
			dyu = dyl = 0;		#y-axis right,left distance
			dd1u = dd1d = 0;		#diagonal distances
			dd2u = dd2d = 0;		#diagonal distances

			k = 0;
			while ( (i-k >= 0) and (src_matrix[i-k][j] != 0) ):
				k = k+1;
			dxl = k;

			k = 0;
			while ( (i+k < self.dim) and (src_matrix[i+k][j] != 0) ):
				k = k+1;
			dxr = k;

			k = 0;
			while ( (j+k < self.dim) and (src_matrix[i][j+k] != 0) ):
				k = k+1;
			dyu = k;

			k = 0;
			while ( (j-k >= 0) and (src_matrix[i][j-k] != 0) ):
				k = k+1;
			dyl = k;

			k = 0;
			while ( (j-k >= 0) and (i-k >= 0) and (src_matrix[i-k][j-k] != 0) ):
				k = k+1;
			dd1u = k;

			k = 0;
			while ( (j+k < self.dim) and (i+k < self.dim) and (src_matrix[i+k][j+k] != 0) ):
				k = k+1;
			dd1d = k;

			k = 0;
			while ( (j-k >= 0) and (i+k <= self.dim) and (src_matrix[i+k][j-k] != 0) ):
				k = k+1;
			dd2u = k;

			k = 0;
			while ( (j+k < self.dim) and (i-k >= 0) and (src_matrix[i-k][j+k] != 0) ):
				k = k+1;
			dd2d = k;
			
			dist_matrix[i][j] = min(dxr,dxl,dyu,dyl,dd1u,dd1d,dd2u,dd2d);

			
	
	
					
	
		
	def TraverseBoundary(self,bounding_letter,(i,j)):

		slope = 0;
		n = 0;
		
		while(True):
			n = n+1;
			if(bounding_letter[i][j] != 1):
				break;

			has_neighbour = 0;
			bounding_letter[i][j] = -1;

			if(bounding_letter[i+1][j+1] == 1):
				slope = slope+1;
				(i,j) = (i+1,j+1);
				continue;
			
			if(bounding_letter[i-1][j-1] == 1):
				slope = slope+1;
				(i,j) = (i-1,j-1);
				continue;
			
			if(bounding_letter[i-1][j+1] == 1):
				slope = slope+1;
				(i,j) = (i-1,j+1);
				continue;
			
			if(bounding_letter[i+1][j-1] == 1):
				slope = slope+1;
				(i,j) = (i+1,j-1);
				continue;

			if(bounding_letter[i+1][j] == 1):
				(i,j) = (i+1,j);
				continue;

			if(bounding_letter[i-1][j] == 1):
				(i,j) = (i-1,j);
				continue;
			
			if(bounding_letter[i][j+1] == 1):
				(i,j) = (i,j+1);
				continue;

			if(bounding_letter[i][j-1] == 1):
				(i,j) = (i,j-1);
				continue;

			

			break;
			
		print slope;
		if(n > 0):
			return float(slope)/n;
		else:
			return 0;

	def SlopeAtPt(self,bounding_letter,(x,y)):
		R = 2;
		N = 0;
		slope = 0;
		L = len(bounding_letter);

		for i in xrange((-1)*R,R+1):
			for j in xrange((-1)*R,R+1):
				if( ((x+i) >= 0) and ((y+j) >= 0) and ((x+i) < L) and ((y+j) < L) and (bounding_letter[x+i][y+j] == 1) ):
					slope = slope + self.cosine((x,y),(x+i,y+j));
					N = N+1;
		if( N == 0 ):
			return -2;

		return float(slope)/N;

	def NearestUnvisited(self,bounding_letter,visited,(x,y)):
		L = len(bounding_letter);
		R = 8;
		for i in xrange((-1)*R,R+1):
			for j in xrange((-1)*R,R+1):
				if( ((x+i) >= 0) and ((y+j) >= 0) and ((x+i) < L) and ((y+j) < L) ):
					if( ( x != 0 ) or ( y != 0) ):
						if( (visited[x+i][y+j] == 0) and (bounding_letter[x+i][y+j] == 1) ):
							return (x+i,y+j);
	
	def TR(self,visited,bounding_letter,(x,y),result_list):
		cur = (x,y);
		while ( cur != None):
			R = 1;
			if( visited[cur[0]][cur[1]] == 0):
				visited[cur[0]][cur[1]] = 1;
				slope = self.SlopeAtPt(bounding_letter,(cur[0],cur[1]));
				result_list.append(slope);
				cur = self.NearestUnvisited(bounding_letter,visited,cur);

	def linearity_measure(self,lst):
		i = 0;
		L = len(lst);
		thresh = 0.1;
		lin_measure = 0;
		while( i < L):
			j=0;
			while( (i+j < L) and (abs(lst[i]- lst[i+j]) <= thresh) ):
				j=j+1;
			
				
			lin_measure = lin_measure + (j-1);
			i=i+j;

		return float(lin_measure)/L;

	def variance(self,lst):
		sum_sl = 0;
		L = len(lst);
		for i in xrange(1,L):
			sum_sl = abs(lst[i-1] - lst[i]);
		return float(sum_sl)/L;
							
			
	def GetSlopeVar(self,bounding_letter):		#mean slope,center of gravity,moments,length

		R = 1;
		L = len(bounding_letter);
		slopes = [];
		N = 0;
		linearity_measure = 0;
		thresh = 0;

		for x in xrange(L):
			for y in xrange(L):
				slope_x_y = 0;
				n_x_y = 0;
				if( bounding_letter[x][y] == 1 ):
					N=N+1;
					for i in xrange((-1)*R,R+1):
						for j in xrange((-1)*R,R+1):
							if( ((x+i) >= 0) and ((y+j) >= 0) and ((x+i) < L) and ((y+j) < L) and (i != 0) and (j != 0) ):
								
								if( (bounding_letter[x+i][y+j] == 1) ):
									slope_x_y = slope_x_y + self.cosine((x,y),(x+i,y+j));
									n_x_y = n_x_y+1;
				if(n_x_y > 0):
					slopes.append( float(slope_x_y)/n_x_y );

		sum_sl = 0;
		len_slopes = len(slopes);
		for x in xrange(1,len_slopes):
			sum_sl = sum_sl + abs( slopes[x-1] + slopes[x] );
		
		
		i = 0;
		while( i < len_slopes):
			j=0;
			while( (i+j < len_slopes) and (abs(slopes[i]- slopes[i+j]) <= thresh) ):
				j=j+1;
			
				
			linearity_measure = linearity_measure + (j-1);
			i=i+j;
		return ( float(sum_sl)/len_slopes,float(linearity_measure)/(len_slopes));
						

	def GetCM(self,img):
		X = 0; Y = 0;
		N = 0;
		L = len(img);
		for x in xrange(L):
			for y in xrange(L):
				if(img[x][y] != 0):
					X = X+x;
					Y = Y+y;
					N=N+1;
		X = float(X)/N;
		Y = float(Y)/N;

		return (X,Y);
			
	def GetMoment(self,img,exp,*argv):
		(X,Y) = self.GetCM(img);
		if( argv != () ):
			(X,Y) = argv[0];
		
		L = len(img);
		moment = 0;
		scale = self.dim;
		N = 0;
		for x in xrange(L):
			for y in xrange(L):
				if(img[x][y] >= 100):
					moment = moment+((float(x)-X)/scale)**exp + ((float(y)-Y)/scale)**exp;
					N = N+1;
		return moment/N;

	def GetLength(self,bounding_img):
		M = len(bounding_img);
		length = 0;
		for x in xrange(M):
			for y in xrange(M):
				if( bounding_img[x][y] == 1):
					bounding_img[x][y] = -1;
					(x1,y1) = self.nearest_neighbour(bounding_img,(x,y));
					if( (x1,y1) != (-1,-1) ):
						length = length + math.sqrt( (x1-x)**2 + (y1-y)**2 );

		for x in xrange(M):
			for y in xrange(M):
				if( bounding_img[x][y] == -1):
					bounding_img[x][y] = 1;
		return length;
		
		
		
	def GetMaxMin(self,bounding_img):
		M = len(bounding_img);
		max_x = 0; min_x = M;
		max_y = 0; min_y = M;

		for x in xrange(M):
			for y in xrange(M):
				if( bounding_img[x][y] == 1):
					if( x > max_x):
						max_x = x;
					if( x < min_x):
						min_x = x;

					if( y > max_y):
						max_y = y;
					if( y < min_y):
						min_y = y;

		return (min_x,max_x,min_y,max_y);

	
	
		
		
class mnist_img:
	training_file = open("training","rb");
	label_file = open("labels","rb");

	magic_number_training = struct.unpack(">I",training_file.read(4));
	magic_number_label = struct.unpack(">I",label_file.read(4));
	
	num_images = struct.unpack(">I",training_file.read(4))[0];
	img_height = struct.unpack(">I",training_file.read(4))[0];
	img_width = struct.unpack(">I",training_file.read(4))[0];
	
	
	def __init__(self,img_index):
		
		mnist_img.training_file.seek(mnist_img.img_height * mnist_img.img_width * img_index +16);
		self.raw_image_data =  mnist_img.training_file.read(mnist_img.img_height * mnist_img.img_width);
		
		mnist_img.label_file.seek(8+img_index);
		self.image_label = struct.unpack(">B",mnist_img.label_file.read(1))[0];
		
	
	def ShowImage(self):
		
		im = Image.frombytes('L',(28,28),self.raw_image_data);
		im.show()

	def GetLabel(self):
		return self.image_label;

	def GetMatrix(self):
		matrix = img_matrix(mnist_img.img_height,self.raw_image_data);
		return matrix;



def PrintTable(label,class_label,R1,R2):
	i = R1;
	table = [];
	while(i <= R2):
		im = mnist_img(i);
		if( im.GetLabel() == label):
			
			im_matrix = im.GetMatrix();
			im_boundary = im_matrix.GetBoundary();
			slopes = []; 
			visited =[ [0 for x in xrange(len(im_boundary)) ] for y in xrange(len(im_boundary)) ];


			im_matrix.TR(visited,im_boundary,im_matrix.GetLowest(im_boundary),slopes);
			lin_measure = im_matrix.linearity_measure(slopes);
			slope_var = im_matrix.variance(slopes);
			(min_x,max_x,min_y,max_y) = im_matrix.GetMaxMin(im_boundary);

			mom2 = im_matrix.GetMoment(im_matrix.matrix,2);
			mom1 = im_matrix.GetMoment(im_matrix.matrix,1);
			mom3 = im_matrix.GetMoment(im_matrix.matrix,1,(min_x,min_y));
			mom4 = im_matrix.GetMoment(im_matrix.matrix,2,(min_x,min_y));
			mom5 = im_matrix.GetMoment(im_matrix.matrix,1,(max_x,max_y));
			mom6 = im_matrix.GetMoment(im_matrix.matrix,2,(max_x,max_y));

			length = im_matrix.GetLength(im_boundary);
			
			num_components = im_matrix.LabelRegions();

			features = [mom1,mom2,mom3,mom4,mom5,mom6,lin_measure,slope_var,length,sum(map(abs,slopes))/length,num_components,min_x,max_x,min_y,max_y,class_label];

			table.append( features);

			print mom1,mom2,mom3,mom4,lin_measure,slope_var,length,sum(map(abs,slopes))/length,num_components,min_x,max_x,min_y,max_y,class_label ; #,mom2,length,slope[0]/length,slope[1],label,class_label;
		i = i+1;
		
	return table;

def BuildData(label1,label2,offset1,offset2,offset3,offset4):

	fname_train = str(label1)+str(label2);
	fname_test = fname_train+'T';
	
	training_features = PrintTable(label1,0,offset1,offset2);
	training_features = training_features + PrintTable(label2,1,offset1,offset2);

	testing_features = PrintTable(label2,0,offset3,offset4);
	testing_features = testing_features+ PrintTable(label2,1,offset3,offset4) ;

	train_file = open(fname_train,'w');

	for vector in training_features:
		for feature in vector:
			train_file.write(str(feature)+" ");
		train_file.write("\n");
	train_file.close();

	test_file = open(fname_test,'w');
	
	for vector in testing_features:
		for feature in vector:
			test_file.write(str(feature)+" ");
		test_file.write("\n");

	test_file.close();

#print "Building..."
#BuildData(7,8,0,1000,1001,3000);
#print "Done Building!";
N = 4000;
train_offsets = (0,N);
test_offsets = (N+1,2*N);

if(sys.argv[3] == '0'):
	PrintTable(int(sys.argv[1]),0,train_offsets[0],train_offsets[1]);
	PrintTable(int(sys.argv[2]),1,train_offsets[0],train_offsets[1]);

if(sys.argv[3] == '1'):
	PrintTable(int(sys.argv[1]),0,test_offsets[0],test_offsets[1]);
	PrintTable(int(sys.argv[2]),1,test_offsets[0],test_offsets[1]);

#while(True):
#	im = mnist_img(int(raw_input()));
#	im_matrix = im.GetMatrix();
#	im_matrix.ShowImage();
#	im_boundary = im_matrix.GetBoundary();
	#slope = im_matrix.GetSlopeVar(im_boundary);
#	visited = [ [0 for x in xrange(0,len(im_boundary))] for y in xrange(0,len(im_boundary)) ];
#	lst = [];
#	(x,y) = im_matrix.GetLowest(im_boundary);
#	im_matrix.TR(visited,im_boundary,(x,y),lst);
#	im_matrix.PrintMatrix(im_boundary);
#	im_matrix.PrintMatrix(visited);
	#print lst;
	#im_matrix.PrintOne(im_boundary);
	#print im.GetLabel(),im_matrix.linearity_measure(lst);


