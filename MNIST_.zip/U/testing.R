

accuracy.new <- function(lin_model,test_data)
{
	res = predict(lin_model,test_data,type="response");
	label_column = length(test_data);
	labels = test_data[,label_column];
	predicted_labels = as.integer( res >= 0.5 );
	accuracy_vector = as.integer(predicted_labels == labels);
	accuracy = sum(accuracy_vector)/length(accuracy_vector);

	return (accuracy);
}

scale.and.center <- function(vec)
{
	mean = sum(vec)/length(vec);
	vec = vec - mean;
	ssq = sum(vec^2);
	if(ssq != 0)
	{
		vec = vec/sqrt(ssq);
	}
	return (vec);
}

distance <- function(x,y)
{
	return ((sum( abs(x-y)) ));
}

weight <- function(x)
{
	return (exp(-20*x));
}

weighted.knn <- function(data,labels,point)
{
	l = dim(data)[1];
	vote = 0;
	for (i in 1:l)
	{
		d = distance(data[i,],point);
		vote = vote + (2*labels[i]-1)*weight(d);
		#print( (2*labels[i]-1)*weight(d));
	}
	return (vote);
}

treat.outliers <- function(data.vec)
{
	m = mean(data.vec);
	v = var(data.vec);
	for(x in c(1:length(data.vec)))
	{
		if( abs(data.vec[x] - m) > 3*sqrt(v))
		{
			data.vec[x] = m;
		}
	}
	return (data.vec);
	
}

load.knn.data <- function()
{
	results = read.table("YEEEE");
	results = results[,-1];
	pred = c();
	for( x in 1:dim(results)[1] )
	{
		for (y in 1:dim(results)[2])
		{
			pred = c(pred,results[x,y]);
		}
	}
	pred = pred[1:(length(pred)-2)];
	return (pred);
}

numitems <- function(vec)
{
	return (length(unique(vec)));
}

bin.vec <-function(vec,breaks)
{
	mx = max(vec);
	mn = min(vec);
	
	h = (mx-mn)/breaks;
	cum = rep(0,breaks);
	for (x in vec)
	{
		
		bin = floor((x-mn)/h)+1;

		if(bin <= breaks)
		{
		cum[bin] = cum[bin]+1;
		}
		else
		{
		cum[breaks] = cum[breaks]+1;
		}
	}

	return (cum);
}

num.comps <- function(pca.mod,thre)		#number of PCA components needed to explain thre variation in pca.model 0 < thre < 1;
{
	sd.vec = pca.mod$sdev;
	var.vec = sd.vec^2;
	prop.vec = (var.vec)/sum(var.vec);

	for (i in (2:length(prop.vec)))
	{
		prop.vec[i] = prop.vec[i-1]+prop.vec[i];
	}

	comps = as.integer(prop.vec < thre);
	ncomps = sum(comps);
	return (ncomps);
}


process.frame <- function(df)
{
	L = length(df);
	for(x in 1:(L-1))
	{
		df[,x] = scale.and.center(df[,x]);
		df[,x] = treat.outliers(df[,x]);
	}
	return (df);
}

perform.logistic <- function(digit1,digit2)
{
	fname1 = sprintf("%i%iT",digit1,digit2);
	fname2 = sprintf("%i%i",digit1,digit2);

	train.data = read.table(fname1);
	test.data = read.table(fname2);
	
	L = length(train.data);

	for(x in c(1:(L-1)))
	{
		
		train.data[,x] = scale.and.center(train.data[,x]);
		train.data[,x] = treat.outliers(train.data[,x]);
		test.data[,x] = scale.and.center(as.vector(test.data[,x]));
		test.data[,x] = treat.outliers(test.data[,x]);
	}

	colnames(train.data)[L] = "label";
	colnames(test.data)[L] = "label";
	
	train.data.pcam = prcomp( train.data[1:(L-1)]);
	test.data.pcam = prcomp(test.data[1:(L-1)]);
	C = num.comps(train.data.pcam,0.85);
	
	train.data.pca = data.frame(predict(train.data.pcam,newdata = train.data)[,1:C]);
	test.data.pca = data.frame(predict(test.data.pcam,newdata = test.data)[,1:C]);

	
	train.data.pca$label = train.data$label;
	test.data.pca$label = test.data$label;
	
	model = glm(label ~ .,train.data.pca,family = "binomial");
	
	#pred = predict(model,test.data.pca,type = "response");
	acc = accuracy.new(model,test.data.pca);
	return (acc);

}

ensemble.knn.pred <- function(vector,label)
{
	vote = 0;
	for(digit in 0:9)
	{
		if(digit != label)
		{
		fname = sprintf("%i%iT",digit,label);
		df = read.table(fname);
		df = process.frame(df);
		L = length(df);
		labels = df[,L];
		vote.l = weighted.knn(df[1:(L-1)],labels,vector);
		print(vote.l);
		vote = vote + vote.l;
		
		}
	}
	return (vote);
}

perform.knn <- function(digit1,digit2,testing.indices)
{
	fname1 = sprintf("%i%iT",digit1,digit2);
	fname2 = sprintf("%i%i",digit1,digit2);

	train.data = read.table(fname1);
	test.data = read.table(fname2);
	
	L = length(train.data);

	for(x in c(1:(L-1)))
	{
		
		train.data[,x] = scale.and.center(train.data[,x]);
		train.data[,x] = treat.outliers(train.data[,x]);
		test.data[,x] = scale.and.center(as.vector(test.data[,x]));
		test.data[,x] = treat.outliers(test.data[,x]);
	}

	colnames(train.data)[L] = "label";
	colnames(test.data)[L] = "label";

	knn.pred = c();
	true.labels = c();

	
	#sample.size = 5;
	#subsample.ind = sample(1:(dim(test.data)[1]),sample.size);

	for ( i in testing.indices)
	{
	vote = weighted.knn(train.data[,1:(L-1)],train.data[,L],test.data[i,1:(L-1)]);
	#print(vote);
	#print(i);
	#print(test.data[i,L]);
	knn.pred = c(knn.pred,vote);
	true.labels = c(true.labels,test.data[i,L]);
	}
	
	return (knn.pred);
	#knn.pred = as.integer(knn.pred > 0);
	#acc.vec = (knn.pred == true.labels);
	#return (acc.vec)/length(acc.vec);
	#model = glm(label ~ .,data = train.data,family = "binomial");
	#acc = accuracy.new(model,test.data[1:200,]);
	#print(acc);
}



